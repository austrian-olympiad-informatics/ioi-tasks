#include <vector>
#include <string>

void construct_network(int H, int W, int K);

int add_and(std::vector<int> Ns);

int add_or(std::vector<int> Ns);

int add_xor(std::vector<int> Ns);

int add_not(int N);
