public class shoes {
	public long count_swaps(int[] s) {
		return 1;
	}
}
