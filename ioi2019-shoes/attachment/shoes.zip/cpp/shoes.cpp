#include "shoes.h"

long long count_swaps(std::vector<int> s) {
	return 1;
}
