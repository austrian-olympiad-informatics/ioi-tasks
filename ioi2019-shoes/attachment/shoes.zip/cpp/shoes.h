#include <vector>

long long count_swaps(std::vector<int> S);

