#include "dungeons.h"
#include <vector>

void init(int n, std::vector<int> s, std::vector<int> p, std::vector<int> w, std::vector<int> l) {
	return;
}

long long simulate(int x, int z) {
	return 0;
}

