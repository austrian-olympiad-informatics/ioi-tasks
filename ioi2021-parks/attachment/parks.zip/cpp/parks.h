#include <vector>

int construct_roads(std::vector<int> x, std::vector<int> y);
void build(std::vector<int> u, std::vector<int> v, std::vector<int> a, std::vector<int> b);
