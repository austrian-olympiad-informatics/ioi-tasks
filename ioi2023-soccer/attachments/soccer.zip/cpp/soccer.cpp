#include "soccer.h"

int biggest_stadium(int N, std::vector<std::vector<int>> F)
{
    return 0;
}
