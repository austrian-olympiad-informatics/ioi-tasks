#include <vector>

int biggest_stadium(int N, std::vector<std::vector<int>> F);
