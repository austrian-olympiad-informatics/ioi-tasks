#include <string>

void init(std::string a, std::string b);
int get_distance(int x, int y);
