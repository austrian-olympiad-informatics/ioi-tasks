#include "registers.h"

void construct_instructions(int s, int n, int k, int q) {
	append_move(1, 0);
	append_right(1, 1, 1);
	append_and(0, 0, 1);
}
